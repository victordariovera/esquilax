<?php $__env->startSection('content'); ?>
<div class="section-title">
    <h1>Novedades</h1>
    <p>changelog de esquilax</p>
    </div>

    <div class="content-empty-container">
        <div class="content-empty">
        <img src="<?php echo e(asset('img/camping.svg')); ?>">
        En GdA estamos creando algo genial, pronto estarà listo!
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/esquilax/root/resources/views/novedades.blade.php ENDPATH**/ ?>