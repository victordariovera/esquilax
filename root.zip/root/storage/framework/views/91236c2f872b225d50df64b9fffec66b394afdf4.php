<?php $__env->startSection('content'); ?>



<div class="login">
    <div class="login_title">
        <img src="img/esquilax_logo_small.svg">Registrate!
     </div>


     <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form__group field">
            <input type="text" class="form__field" placeholder="Nombre" name="name" id='name' required />
            <label for="name" class="form__label">Nombre:</label>

            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>

     <div class="form__group field">
         <input type="email" class="form__field" placeholder="Email" name="email" id='email' required />
         <label for="name" class="form__label">Email:</label>

         <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
         <span class="invalid-feedback" role="alert">
             <strong><?php echo e($message); ?></strong>
         </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

       </div>

       <div class="form__group field">
         <input type="password" class="form__field" placeholder="password" name="password" id='password' required />
         <label for="name" class="form__label">Password:</label>

         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
         <span class="invalid-feedback" role="alert">
             <strong><?php echo e($message); ?></strong>
         </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


       </div>

       <div class="form__group field">
        <input type="password" class="form__field" placeholder="Confirmá tu Password" name="password_confirmation" id='password_confirmation' required />
        <label for="name" class="form__label">Confirmá tu Password:</label>
      </div>

       <div class="form__group field">
           <input class="btn_std" type="submit" value="Ingresar">
       </div>

    </form>
</div>
<div class="login_art">

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/esquilax/root/resources/views/auth/register.blade.php ENDPATH**/ ?>