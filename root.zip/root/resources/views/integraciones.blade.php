@extends('layouts.default')
@section('content')
<div class="section-title">
    <h1>Integraciones</h1>
    <p>Vínculos entre sistemas</p>
    </div>

    <div class="content-empty-container">
        <div class="content-empty">
        <img src="{{ asset('img/camping.svg') }}">
        En GdA estamos creando algo genial, pronto estarà listo!
        </div>
    </div>

@endsection
