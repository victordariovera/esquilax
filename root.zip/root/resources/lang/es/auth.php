<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'No se encuentra este usuario o contraseña en nuestros registros',
    'throttle' => 'Demaciados intentos de login, pruebe nuevamente en :seconds seconds.',

];
